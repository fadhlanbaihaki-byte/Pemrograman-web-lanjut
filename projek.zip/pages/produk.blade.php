@extends('layouts.app')
@section('title', 'Produk - Dapur Ayu')
@section('content')

    {{-- ===== PAGE HEADER ===== --}}
    <section class="page-header">
        <div class="container text-center">
            <span class="section-label fade-up" style="display:block;"></span>
            <h1 class="page-header-title fade-up">Produk Kami</h1>
            <nav aria-label="breadcrumb" class="fade-up">
                <ol class="breadcrumb justify-content-center" style="font-size:13px;">
                    <li class="breadcrumb-item"><a href="{{ url('/') }}" style="color:var(--color-primary);">Beranda</a></li>
                    <li class="breadcrumb-item active" aria-current="page" style="color:var(--color-muted);">Produk</li>
                </ol>
            </nav>
        </div>
    </section>

    <section class="section-padding">
        <div class="container">

            {{-- ===== SEARCH & FILTER ===== --}}
            <div class="row align-items-center g-3 mb-5 fade-up">

                {{-- Search Bar --}}
                <div class="col-lg-5">
                    <div class="search-wrap">
                        <i class="bi bi-search search-icon"></i>
                        <input type="text" id="searchInput" class="search-input"
                               placeholder="Cari produk... (contoh: rubber o ring, tekstil dll)">
                    </div>
                </div>

                {{-- Filter Kategori --}}
                <div class="col-lg-7">
                    <div class="filter-pills" id="filterPills">
                        <button class="filter-pill active" data-filter="all">Semua</button>
                        <button class="filter-pill" data-filter="kue">Kue & Roti</button>
                        <button class="filter-pill" data-filter="kering">Kue Kering</button>
                        <button class="filter-pill" data-filter="snack">Snack</button>
                        <button class="filter-pill" data-filter="minuman">Minuman</button>
                        <button class="filter-pill" data-filter="masakan">Masakan</button>
                        <button class="filter-pill" data-filter="hampers">Hampers</button>
                    </div>
                </div>

            </div>

            {{-- ===== PRODUCT GRID ===== --}}
            @php
            $allProducts = [
                ['id'=>1,  'slug'=>'brownies-cokelat-premium',  'name'=>'Brownies Cokelat Premium',   'category'=>'Kue & Roti',  'cat_key'=>'kue',     'price'=>'Rp 65.000', 'short_desc'=>'Brownies lembut dengan cokelat Belgian premium, tekstur fudgy yang menggugah selera.',         'image'=>'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=400&q=80', 'badge'=>'Best'],
                ['id'=>2,  'slug'=>'nastar-keju-premium',       'name'=>'Nastar Keju Premium',        'category'=>'Kue Kering',  'cat_key'=>'kering',  'price'=>'Rp 85.000', 'short_desc'=>'Nastar isian selai nanas homemade, taburan keju parmesan yang gurih.',                          'image'=>'https://images.unsplash.com/photo-1517093157656-b9eccef91cb1?w=400&q=80', 'badge'=>'Best'],
                ['id'=>3,  'slug'=>'es-teh-tarik',              'name'=>'Es Teh Tarik Premium',       'category'=>'Minuman',     'cat_key'=>'minuman', 'price'=>'Rp 18.000', 'short_desc'=>'Teh tarik ala kafe dengan rasa otentik, tersedia dalam botol 350ml siap minum.',              'image'=>'https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=400&q=80', 'badge'=>'New'],
                ['id'=>4,  'slug'=>'rendang-sapi',              'name'=>'Rendang Sapi Premium',       'category'=>'Masakan',     'cat_key'=>'masakan', 'price'=>'Rp 120.000','short_desc'=>'Rendang sapi daging pilihan, dimasak 6 jam dengan 30+ bumbu rempah asli Minang.',             'image'=>'https://images.unsplash.com/photo-1637806931008-eeb1bc6e4b47?w=400&q=80', 'badge'=>'Best'],
                ['id'=>5,  'slug'=>'kue-lapis-legit',           'name'=>'Lapis Legit Spekuk',         'category'=>'Kue & Roti',  'cat_key'=>'kue',     'price'=>'Rp 195.000','short_desc'=>'Lapis legit premium 40 layer dengan rempah spekuk khas Belanda-Indonesia yang autentik.',     'image'=>'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=400&q=80'],
                ['id'=>6,  'slug'=>'kue-putri-salju',           'name'=>'Putri Salju Keju',           'category'=>'Kue Kering',  'cat_key'=>'kering',  'price'=>'Rp 75.000', 'short_desc'=>'Kue putri salju lembut dengan isian keju yang creamy, dibalut tepung gula halus.',            'image'=>'https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=400&q=80'],
                ['id'=>7,  'slug'=>'keripik-tempe',             'name'=>'Keripik Tempe Renyah',       'category'=>'Snack',       'cat_key'=>'snack',   'price'=>'Rp 25.000', 'short_desc'=>'Keripik tempe tipis renyah dengan pilihan rasa original, balado, dan pedas manis.',           'image'=>'https://images.unsplash.com/photo-1604329760661-e71dc83f8f26?w=400&q=80', 'badge'=>'New'],
                ['id'=>8,  'slug'=>'susu-kurma',                'name'=>'Susu Kurma Segar',           'category'=>'Minuman',     'cat_key'=>'minuman', 'price'=>'Rp 22.000', 'short_desc'=>'Susu kurma segar tanpa pengawet, kaya nutrisi dan sangat menyegarkan, botol 350ml.',           'image'=>'https://images.unsplash.com/photo-1544145945-f90425340c7e?w=400&q=80'],
                ['id'=>9,  'slug'=>'ayam-bumbu-bali',           'name'=>'Ayam Bumbu Bali',            'category'=>'Masakan',     'cat_key'=>'masakan', 'price'=>'Rp 85.000', 'short_desc'=>'Ayam kampung segar dengan bumbu Bali yang kaya rempah dan pedas menggiurkan.',              'image'=>'https://images.unsplash.com/photo-1598514983318-2f64f8f4796c?w=400&q=80'],
                ['id'=>10, 'slug'=>'hampers-lebaran-premium',   'name'=>'Hampers Lebaran Premium',    'category'=>'Hampers',     'cat_key'=>'hampers', 'price'=>'Rp 350.000','short_desc'=>'Paket hampers lebaran berisi aneka kue kering premium dalam toples cantik siap hadir.',       'image'=>'https://images.unsplash.com/photo-1607344645866-009c320b63e0?w=400&q=80', 'badge'=>'New'],
                ['id'=>11, 'slug'=>'roti-sobek-keju',           'name'=>'Roti Sobek Keju Susu',       'category'=>'Kue & Roti',  'cat_key'=>'kue',     'price'=>'Rp 45.000', 'short_desc'=>'Roti sobek lembut dengan isian keju dan susu yang melimpah, fresh from the oven.',           'image'=>'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400&q=80'],
                ['id'=>12, 'slug'=>'klepon-pandan',             'name'=>'Klepon Pandan Kelapa',       'category'=>'Snack',       'cat_key'=>'snack',   'price'=>'Rp 20.000', 'short_desc'=>'Klepon tradisional berbahan tepung ketan pandan segar dengan isian gula merah dan kelapa parut.','image'=>'https://images.unsplash.com/photo-1565299507177-b0ac66763828?w=400&q=80'],
            ];
            @endphp

            {{-- Product Count --}}
            <div class="d-flex justify-content-between align-items-center mb-4 fade-up">
                <p style="font-size:13px; color:var(--color-muted); margin:0;">
                    Menampilkan <span id="productCount" style="font-weight:600; color:var(--color-dark);">{{ count($allProducts) }}</span> produk
                </p>
                <select class="sort-select" id="sortSelect">
                    <option value="default">Urutkan: Default</option>
                    <option value="name">Nama A-Z</option>
                    <option value="price-low">Harga Terendah</option>
                    <option value="price-high">Harga Tertinggi</option>
                </select>
            </div>

            {{-- Grid --}}
            <div class="row g-4" id="productGrid">
                @foreach($allProducts as $i => $product)
                <div class="col-lg-3 col-md-4 col-sm-6 product-item fade-up"
                     data-category="{{ $product['cat_key'] }}"
                     data-name="{{ strtolower($product['name']) }}"
                     style="transition-delay: {{ ($i % 4) * 0.08 }}s;">
                    @include('components.product-card', ['product' => $product])
                </div>
                @endforeach
            </div>

            {{-- No Results Message --}}
            <div id="noResults" class="text-center py-5" style="display:none;">
                <i class="bi bi-search" style="font-size:3rem; color:var(--color-border);"></i>
                <h5 style="font-family:var(--font-display); margin-top:16px; color:var(--color-muted);">Produk tidak ditemukan</h5>
                <p style="font-size:14px; color:var(--color-muted);">Coba kata kunci lain atau reset filter</p>
                <button onclick="resetFilter()" class="btn-outline-custom mt-2">Reset Filter</button>
            </div>

            {{-- ===== PAGINATION ===== --}}
            <div class="pagination-wrap fade-up mt-5" id="paginationWrap">
                <nav aria-label="Pagination">
                    <ul class="pagination-custom">
                        <li>
                            <button class="page-btn prev-btn" disabled>
                                <i class="bi bi-chevron-left"></i>
                            </button>
                        </li>
                        <li><button class="page-btn active">1</button></li>
                        <li><button class="page-btn">2</button></li>
                        <li><button class="page-btn">3</button></li>
                        <li>
                            <button class="page-btn next-btn">
                                <i class="bi bi-chevron-right"></i>
                            </button>
                        </li>
                    </ul>
                </nav>
            </div>

        </div>
    </section>

@endsection

@push('styles')
<style>
    .page-header {
        background: linear-gradient(135deg, #fdf8f4 0%, #f5ede3 100%);
        padding: 60px 0 50px;
        border-bottom: 1px solid var(--color-border);
    }
    .page-header-title {
        font-family: var(--font-display);
        font-size: clamp(2rem, 4vw, 3rem);
        margin-bottom: 12px;
    }

    /* Search */
    .search-wrap {
        position: relative;
    }
    .search-icon {
        position: absolute;
        left: 16px; top: 50%;
        transform: translateY(-50%);
        color: var(--color-muted);
        font-size: 15px;
    }
    .search-input {
        width: 100%;
        padding: 12px 16px 12px 44px;
        border: 1.5px solid var(--color-border);
        border-radius: 50px;
        font-family: var(--font-body);
        font-size: 14px;
        background: white;
        color: var(--color-text);
        transition: var(--transition);
        outline: none;
    }
    .search-input:focus {
        border-color: var(--color-primary);
        box-shadow: 0 0 0 3px rgba(200, 149, 108, 0.12);
    }

    /* Filter Pills */
    .filter-pills {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
    }
    .filter-pill {
        padding: 8px 18px;
        border: 1.5px solid var(--color-border);
        border-radius: 50px;
        background: white;
        font-family: var(--font-body);
        font-size: 13px;
        font-weight: 500;
        color: var(--color-text);
        cursor: pointer;
        transition: var(--transition);
    }
    .filter-pill:hover,
    .filter-pill.active {
        background: var(--color-primary);
        border-color: var(--color-primary);
        color: white;
    }

    /* Sort Select */
    .sort-select {
        padding: 8px 14px;
        border: 1.5px solid var(--color-border);
        border-radius: 50px;
        font-family: var(--font-body);
        font-size: 13px;
        color: var(--color-text);
        background: white;
        cursor: pointer;
        outline: none;
        transition: var(--transition);
    }
    .sort-select:focus { border-color: var(--color-primary); }

    /* Pagination */
    .pagination-wrap { display: flex; justify-content: center; }
    .pagination-custom {
        list-style: none;
        padding: 0;
        margin: 0;
        display: flex;
        gap: 6px;
        align-items: center;
    }
    .page-btn {
        width: 40px; height: 40px;
        border: 1.5px solid var(--color-border);
        border-radius: 50%;
        background: white;
        font-family: var(--font-body);
        font-size: 14px;
        font-weight: 500;
        color: var(--color-text);
        cursor: pointer;
        transition: var(--transition);
        display: flex; align-items: center; justify-content: center;
    }
    .page-btn:hover:not(:disabled) {
        border-color: var(--color-primary);
        color: var(--color-primary);
    }
    .page-btn.active {
        background: var(--color-primary);
        border-color: var(--color-primary);
        color: white;
    }
    .page-btn:disabled { opacity: 0.4; cursor: not-allowed; }

    /* Product hidden state */
    .product-item.hidden { display: none !important; }
</style>
@endpush

@push('scripts')
<script>
    // === SEARCH & FILTER FUNCTIONALITY ===
    const searchInput  = document.getElementById('searchInput');
    const filterPills  = document.querySelectorAll('.filter-pill');
    const productItems = document.querySelectorAll('.product-item');
    const noResults    = document.getElementById('noResults');
    const productCount = document.getElementById('productCount');

    let activeFilter = 'all';

    function filterProducts() {
        const query = searchInput.value.toLowerCase().trim();
        let visibleCount = 0;

        productItems.forEach(item => {
            const name = item.getAttribute('data-name');
            const cat  = item.getAttribute('data-category');

            const matchesSearch = query === '' || name.includes(query);
            const matchesFilter = activeFilter === 'all' || cat === activeFilter;

            if (matchesSearch && matchesFilter) {
                item.classList.remove('hidden');
                visibleCount++;
            } else {
                item.classList.add('hidden');
            }
        });

        productCount.textContent = visibleCount;
        noResults.style.display = visibleCount === 0 ? 'block' : 'none';
        document.getElementById('paginationWrap').style.display = visibleCount === 0 ? 'none' : 'flex';
    }

    // Filter pill click
    filterPills.forEach(pill => {
        pill.addEventListener('click', () => {
            filterPills.forEach(p => p.classList.remove('active'));
            pill.classList.add('active');
            activeFilter = pill.getAttribute('data-filter');
            filterProducts();
        });
    });

    // Search input
    searchInput.addEventListener('input', filterProducts);

    // Reset function
    function resetFilter() {
        searchInput.value = '';
        activeFilter = 'all';
        filterPills.forEach(p => p.classList.remove('active'));
        document.querySelector('[data-filter="all"]').classList.add('active');
        filterProducts();
    }
</script>
@endpush