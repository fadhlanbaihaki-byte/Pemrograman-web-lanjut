{{-- ============================================
     PAGE: Detail Produk
     File: resources/views/pages/produk-detail.blade.php
============================================ --}}

@extends('layouts.app')

@section('title', 'Brownies Cokelat Premium - Dapur Ayu')

@section('content')

    {{-- ===== PAGE HEADER ===== --}}
    <section class="page-header-mini">
        <div class="container">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb" style="font-size:13px; margin:0;">
                    <li class="breadcrumb-item"><a href="{{ url('/') }}" style="color:var(--color-primary);">Beranda</a></li>
                    <li class="breadcrumb-item"><a href="{{ url('/produk') }}" style="color:var(--color-primary);">Produk</a></li>
                    <li class="breadcrumb-item active" style="color:var(--color-muted);">Brownies Cokelat Premium</li>
                </ol>
            </nav>
        </div>
    </section>

    {{-- ===== PRODUCT DETAIL ===== --}}
    <section class="section-padding">
        <div class="container">
            <div class="row g-5">

                {{-- Left: Images --}}
                <div class="col-lg-6 fade-up">
                    <div class="product-gallery">

                        {{-- Main Image --}}
                        <div class="gallery-main">
                            <img id="mainImg"
                                 src="https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=700&q=80"
                                 alt="Brownies Cokelat Premium">
                            <div class="gallery-badge">Best Seller</div>
                        </div>

                        {{-- Thumbnail Images --}}
                        <div class="gallery-thumbs">
                            @php
                            $thumbs = [
                                'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=200&q=80',
                                'https://images.unsplash.com/photo-1564355808539-22fda35bed7e?w=200&q=80',
                                'https://images.unsplash.com/photo-1515037893149-de7f840978e2?w=200&q=80',
                                'https://images.unsplash.com/photo-1563729784474-d77dbb933a9e?w=200&q=80',
                            ];
                            @endphp
                            @foreach($thumbs as $i => $thumb)
                            <div class="gallery-thumb {{ $i === 0 ? 'active' : '' }}"
                                 onclick="changeImg('{{ $thumb }}', this)">
                                <img src="{{ $thumb }}" alt="Foto {{ $i+1 }}">
                            </div>
                            @endforeach
                        </div>

                    </div>
                </div>

                {{-- Right: Info --}}
                <div class="col-lg-6 fade-up">
                    <div class="product-detail-info">

                        <div class="product-category-tag">Kue & Roti</div>

                        <h1 class="product-detail-name">Brownies Cokelat Premium</h1>

                        {{-- Rating --}}
                        <div class="product-rating">
                            @for($i=0; $i<5; $i++)
                            <i class="bi bi-star-fill" style="color:#f0a500; font-size:14px;"></i>
                            @endfor
                            <span style="font-size:13px; color:var(--color-muted); margin-left:8px;">5.0 (128 ulasan)</span>
                        </div>

                        <div class="product-detail-price">Rp 65.000</div>

                        <div class="divider-elegant"></div>

                        {{-- Short Description --}}
                        <p class="product-detail-desc">
                            Brownies premium dengan cita rasa cokelat Belgian yang kaya dan intens. Tekstur fudgy yang lembut di dalam dengan lapisan atas yang sedikit crispy. Dibuat tanpa bahan pengawet, cocok untuk camilan keluarga maupun hadiah spesial.
                        </p>

                        {{-- Product Details --}}
                        <div class="product-spec-table">
                            <div class="spec-row">
                                <div class="spec-label">Berat</div>
                                <div class="spec-value">500 gram (22x11 cm)</div>
                            </div>
                            <div class="spec-row">
                                <div class="spec-label">Komposisi</div>
                                <div class="spec-value">Cokelat Belgian, tepung, telur, butter, gula</div>
                            </div>
                            <div class="spec-row">
                                <div class="spec-label">Ketahanan</div>
                                <div class="spec-value">3 hari suhu ruang, 7 hari kulkas</div>
                            </div>
                            <div class="spec-row">
                                <div class="spec-label">Varian</div>
                                <div class="spec-value">Original, Keju, Kacang, Red Velvet</div>
                            </div>
                            <div class="spec-row">
                                <div class="spec-label">Min. Order</div>
                                <div class="spec-value">1 loyang (bisa custom)</div>
                            </div>
                        </div>

                        {{-- Variants --}}
                        <div class="mb-4">
                            <div style="font-size:13px; font-weight:600; margin-bottom:10px; color:var(--color-dark);">Pilih Varian:</div>
                            <div class="variant-pills">
                                <button class="variant-pill active">Original</button>
                                <button class="variant-pill">Keju</button>
                                <button class="variant-pill">Kacang</button>
                                <button class="variant-pill">Red Velvet</button>
                            </div>
                        </div>

                        {{-- Actions --}}
                        <div class="product-actions">
                            <a href="https://wa.me/6281234567890?text=Halo%20Dapur%20Ayu,%20saya%20ingin%20memesan%20*Brownies%20Cokelat%20Premium*%20(Original).%20Mohon%20info%20lebih%20lanjut."
                               class="btn-wa" target="_blank" style="flex:1; justify-content:center;">
                                <i class="bi bi-whatsapp"></i>
                                Pesan via WhatsApp
                            </a>
                            <a href="{{ url('/produk') }}" class="btn-outline-custom">
                                <i class="bi bi-grid-3x3-gap"></i>
                            </a>
                        </div>

                        {{-- Info Notes --}}
                        <div class="product-notes">
                            <div class="note-item">
                                <i class="bi bi-truck" style="color:var(--color-primary);"></i>
                                <span>Pengiriman same-day area Bekasi (order sebelum pukul 12.00)</span>
                            </div>
                            <div class="note-item">
                                <i class="bi bi-shield-check" style="color:var(--color-primary);"></i>
                                <span>100% bahan alami, tanpa pengawet buatan</span>
                            </div>
                            <div class="note-item">
                                <i class="bi bi-gift" style="color:var(--color-primary);"></i>
                                <span>Tersedia gift packaging + kartu ucapan gratis</span>
                            </div>
                        </div>

                    </div>
                </div>

            </div>

            {{-- ===== DESKRIPSI LENGKAP ===== --}}
            <div class="row mt-5">
                <div class="col-12">
                    <div class="product-tabs fade-up">
                        <div class="tabs-header">
                            <button class="tab-btn active" data-tab="deskripsi">Deskripsi Produk</button>
                            <button class="tab-btn" data-tab="cara">Cara Penyimpanan</button>
                            <button class="tab-btn" data-tab="ulasan">Ulasan (128)</button>
                        </div>

                        <div class="tab-content-custom">

                            {{-- Deskripsi --}}
                            <div class="tab-pane-custom active" id="tab-deskripsi">
                                <h5 style="font-family:var(--font-display);">Tentang Produk</h5>
                                <p>Brownies Cokelat Premium Dapur Ayu dibuat menggunakan cokelat Belgian berkualitas tinggi yang diimpor langsung, memberikan cita rasa cokelat yang kaya, intens, dan berkesan. Setiap loyang dibuat dengan penuh perhatian untuk memastikan tekstur yang sempurna.</p>
                                <p>Kami menggunakan butter pilihan berkualitas tinggi yang memberikan kelembutan khas dan aroma yang menggugah selera. Tanpa tambahan essens buatan — semua aroma berasal dari bahan asli yang kami gunakan.</p>
                                <h6 style="font-family:var(--font-display); margin-top:24px;">Komposisi Bahan:</h6>
                                <ul style="color:var(--color-muted); font-size:14px; line-height:2;">
                                    <li>Cokelat Belgian 60% cacao premium</li>
                                    <li>Tepung terigu protein rendah pilihan</li>
                                    <li>Telur ayam kampung segar</li>
                                    <li>Butter imported berkualitas tinggi</li>
                                    <li>Gula pasir halus & gula palem</li>
                                    <li>Vanili alami</li>
                                    <li><em>Tidak mengandung bahan pengawet</em></li>
                                </ul>
                            </div>

                            {{-- Cara Simpan --}}
                            <div class="tab-pane-custom" id="tab-cara" style="display:none;">
                                <h5 style="font-family:var(--font-display);">Cara Penyimpanan</h5>
                                <div class="row g-3 mt-2">
                                    @php
                                    $storages = [
                                        ['icon'=>'bi-thermometer-sun',  'title'=>'Suhu Ruang', 'desc'=>'Tahan 3 hari dalam wadah tertutup rapat, jauhkan dari sinar matahari langsung.'],
                                        ['icon'=>'bi-snow',             'title'=>'Kulkas',     'desc'=>'Tahan 7 hari dalam kulkas. Keluarkan 15 menit sebelum disajikan agar kembali lembut.'],
                                        ['icon'=>'bi-browser-firefox',  'title'=>'Freezer',    'desc'=>'Bisa disimpan di freezer hingga 1 bulan. Thawing di kulkas, bukan suhu ruang.'],
                                    ];
                                    @endphp
                                    @foreach($storages as $s)
                                    <div class="col-md-4">
                                        <div style="background:var(--color-bg); border-radius:var(--radius-md); padding:20px; text-align:center;">
                                            <i class="bi {{ $s['icon'] }}" style="font-size:2rem; color:var(--color-primary); margin-bottom:12px; display:block;"></i>
                                            <h6 style="font-family:var(--font-display);">{{ $s['title'] }}</h6>
                                            <p style="font-size:13px; color:var(--color-muted); margin:0;">{{ $s['desc'] }}</p>
                                        </div>
                                    </div>
                                    @endforeach
                                </div>
                            </div>

                            {{-- Ulasan --}}
                            <div class="tab-pane-custom" id="tab-ulasan" style="display:none;">
                                <div class="review-summary">
                                    <div class="review-score">5.0</div>
                                    <div>
                                        <div class="d-flex gap-1 mb-2">
                                            @for($i=0; $i<5; $i++)
                                            <i class="bi bi-star-fill" style="color:#f0a500; font-size:18px;"></i>
                                            @endfor
                                        </div>
                                        <div style="font-size:13px; color:var(--color-muted);">Dari 128 ulasan pelanggan</div>
                                    </div>
                                </div>

                                @php
                                $reviews = [
                                    ['name'=>'Dewi R.', 'rating'=>5, 'date'=>'2 hari lalu', 'text'=>'Enak banget! Cokelat-nya kerasa banget, nggak terlalu manis. Teksturnya lembut dan fudgy sesuai yang dijanjikan. Pasti repeat order!'],
                                    ['name'=>'Arif H.', 'rating'=>5, 'date'=>'1 minggu lalu', 'text'=>'Beli varian keju, gurihnya juara! Packaging-nya juga rapi dan higienis. Pengiriman cepat dan tepat waktu. Recommended banget!'],
                                    ['name'=>'Maya S.', 'rating'=>5, 'date'=>'2 minggu lalu', 'text'=>'Sudah 5x beli dan selalu puas. Konsisten banget rasa dan kualitasnya. Dapur Ayu emang terbaik untuk brownies di Bekasi.'],
                                ];
                                @endphp
                                <div class="reviews-list mt-4">
                                    @foreach($reviews as $r)
                                    <div class="review-item">
                                        <div class="d-flex justify-content-between align-items-start mb-2">
                                            <div>
                                                <strong style="font-size:14px;">{{ $r['name'] }}</strong>
                                                <div class="d-flex gap-1 mt-1">
                                                    @for($i=0; $i<$r['rating']; $i++)
                                                    <i class="bi bi-star-fill" style="color:#f0a500; font-size:11px;"></i>
                                                    @endfor
                                                </div>
                                            </div>
                                            <span style="font-size:12px; color:var(--color-muted);">{{ $r['date'] }}</span>
                                        </div>
                                        <p style="font-size:14px; color:var(--color-text); margin:0; line-height:1.7;">{{ $r['text'] }}</p>
                                    </div>
                                    @endforeach
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>

    {{-- ===== RELATED PRODUCTS ===== --}}
    <section class="section-padding bg-light-warm">
        <div class="container">

            <div class="d-flex align-items-end justify-content-between mb-5 flex-wrap gap-3">
                <div class="fade-up">
                    <span class="section-label">Lainnya</span>
                    <h2 class="section-title mb-0">Produk Terkait</h2>
                    <div class="divider-elegant"></div>
                </div>
                <a href="{{ url('/produk') }}" class="btn-outline-custom fade-up">
                    Semua Produk <i class="bi bi-arrow-right"></i>
                </a>
            </div>

            @php
            $related = [
                ['id'=>5,'slug'=>'kue-lapis-legit','name'=>'Lapis Legit Spekuk','category'=>'Kue & Roti','price'=>'Rp 195.000','short_desc'=>'Lapis legit premium 40 layer dengan rempah spekuk khas.','image'=>'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=400&q=80'],
                ['id'=>11,'slug'=>'roti-sobek-keju','name'=>'Roti Sobek Keju Susu','category'=>'Kue & Roti','price'=>'Rp 45.000','short_desc'=>'Roti sobek lembut dengan isian keju dan susu yang melimpah.','image'=>'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400&q=80'],
                ['id'=>2,'slug'=>'nastar-keju-premium','name'=>'Nastar Keju Premium','category'=>'Kue Kering','price'=>'Rp 85.000','short_desc'=>'Nastar isian selai nanas homemade dengan taburan keju parmesan.','image'=>'https://images.unsplash.com/photo-1517093157656-b9eccef91cb1?w=400&q=80','badge'=>'Best'],
                ['id'=>6,'slug'=>'kue-putri-salju','name'=>'Putri Salju Keju','category'=>'Kue Kering','price'=>'Rp 75.000','short_desc'=>'Kue putri salju lembut dengan isian keju yang creamy.','image'=>'https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=400&q=80'],
            ];
            @endphp

            <div class="row g-4">
                @foreach($related as $i => $product)
                <div class="col-lg-3 col-md-6 fade-up" style="transition-delay: {{ $i * 0.1 }}s;">
                    @include('components.product-card', ['product' => $product])
                </div>
                @endforeach
            </div>

        </div>
    </section>

@endsection

@push('styles')
<style>
    .page-header-mini {
        background: var(--color-bg);
        padding: 18px 0;
        border-bottom: 1px solid var(--color-border);
    }

    /* Gallery */
    .product-gallery { position: sticky; top: 100px; }
    .gallery-main {
        border-radius: var(--radius-lg);
        overflow: hidden;
        position: relative;
        height: 440px;
        background: #f5f0eb;
        margin-bottom: 12px;
    }
    .gallery-main img {
        width: 100%; height: 100%;
        object-fit: cover;
        transition: transform 0.4s ease;
    }
    .gallery-main:hover img { transform: scale(1.03); }
    .gallery-badge {
        position: absolute; top: 16px; left: 16px;
        background: var(--color-primary); color: white;
        font-size: 11px; font-weight: 600; letter-spacing: 1.5px;
        text-transform: uppercase; padding: 5px 14px; border-radius: 50px;
    }

    .gallery-thumbs { display: flex; gap: 8px; }
    .gallery-thumb {
        flex: 1;
        height: 80px;
        border-radius: var(--radius-sm);
        overflow: hidden;
        cursor: pointer;
        border: 2px solid transparent;
        transition: var(--transition);
    }
    .gallery-thumb img { width: 100%; height: 100%; object-fit: cover; }
    .gallery-thumb:hover,
    .gallery-thumb.active { border-color: var(--color-primary); }

    /* Product Info */
    .product-category-tag {
        font-size: 11px; font-weight: 600; letter-spacing: 2px;
        text-transform: uppercase; color: var(--color-primary);
        margin-bottom: 8px;
    }
    .product-detail-name {
        font-family: var(--font-display);
        font-size: clamp(1.6rem, 3vw, 2.2rem);
        margin-bottom: 12px;
    }
    .product-rating { display: flex; align-items: center; margin-bottom: 16px; }
    .product-detail-price {
        font-family: var(--font-display);
        font-size: 2rem; font-weight: 600;
        color: var(--color-primary); margin-bottom: 20px;
    }
    .product-detail-desc {
        font-size: 14px; color: var(--color-muted);
        line-height: 1.85; margin-bottom: 20px;
    }

    /* Spec Table */
    .product-spec-table { margin-bottom: 24px; }
    .spec-row {
        display: flex; gap: 12px; padding: 10px 0;
        border-bottom: 1px solid var(--color-border); font-size: 14px;
    }
    .spec-row:last-child { border-bottom: none; }
    .spec-label { font-weight: 600; color: var(--color-dark); width: 110px; flex-shrink: 0; }
    .spec-value { color: var(--color-muted); }

    /* Variant Pills */
    .variant-pills { display: flex; gap: 8px; flex-wrap: wrap; }
    .variant-pill {
        padding: 7px 16px;
        border: 1.5px solid var(--color-border);
        border-radius: 50px; background: white;
        font-size: 13px; font-weight: 500; cursor: pointer;
        transition: var(--transition); color: var(--color-text);
    }
    .variant-pill:hover,
    .variant-pill.active {
        border-color: var(--color-primary);
        color: var(--color-primary);
        background: var(--color-primary-light);
    }

    /* Actions */
    .product-actions {
        display: flex; gap: 10px; margin-bottom: 20px;
    }

    /* Notes */
    .product-notes { display: flex; flex-direction: column; gap: 10px; }
    .note-item {
        display: flex; align-items: center; gap: 10px;
        font-size: 13px; color: var(--color-muted);
    }

    /* Tabs */
    .product-tabs {
        background: white; border-radius: var(--radius-lg);
        border: 1px solid var(--color-border); overflow: hidden;
    }
    .tabs-header {
        display: flex; border-bottom: 1px solid var(--color-border);
        padding: 0 24px;
    }
    .tab-btn {
        padding: 16px 20px; border: none; background: none;
        font-family: var(--font-body); font-size: 14px; font-weight: 500;
        color: var(--color-muted); cursor: pointer; transition: var(--transition);
        border-bottom: 2px solid transparent; margin-bottom: -1px;
    }
    .tab-btn:hover { color: var(--color-primary); }
    .tab-btn.active { color: var(--color-primary); border-bottom-color: var(--color-primary); }
    .tab-content-custom { padding: 32px; }
    .tab-content-custom p { font-size: 14px; color: var(--color-muted); line-height: 1.85; }

    /* Reviews */
    .review-summary { display: flex; align-items: center; gap: 20px; margin-bottom: 8px; }
    .review-score { font-family: var(--font-display); font-size: 3.5rem; font-weight: 600; color: var(--color-dark); }
    .review-item {
        padding: 18px 0;
        border-bottom: 1px solid var(--color-border);
    }
    .review-item:last-child { border-bottom: none; }

    @media (max-width: 991px) {
        .product-gallery { position: static; }
        .gallery-main { height: 320px; }
    }
</style>
@endpush

@push('scripts')
<script>
    // Gallery image switcher
    function changeImg(src, el) {
        document.getElementById('mainImg').src = src.replace('200', '700');
        document.querySelectorAll('.gallery-thumb').forEach(t => t.classList.remove('active'));
        el.classList.add('active');
    }

    // Variant pills
    document.querySelectorAll('.variant-pill').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.variant-pill').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
        });
    });

    // Tabs
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const target = this.getAttribute('data-tab');
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.tab-pane-custom').forEach(p => p.style.display = 'none');
            this.classList.add('active');
            document.getElementById('tab-' + target).style.display = 'block';
        });
    });
</script>
@endpush